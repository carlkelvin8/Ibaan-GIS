// frontend/src/components/Sidebar/Sidebar.jsx
import React, { useEffect, useState, useCallback } from "react";
import { Collapse } from "react-bootstrap";
import { NavLink, useNavigate, useLocation } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap-icons/font/bootstrap-icons.css";
import "./Sidebar.css";

const OPEN_W = 300;      // expanded width
const COLLAPSED_W = 92;  // collapsed width (adjust 88–100 to taste)

// --- Auth helpers (match App.jsx) ---
function getToken() {
  const raw =
    localStorage.getItem("token") ||
    sessionStorage.getItem("token") ||
    "";
  return raw.startsWith("Bearer ") ? raw.slice(7) : raw;
}

function getRoleFromToken() {
  try {
    const token = getToken();
    const payload = token.split(".")[1];
    if (!payload) return null;
    const json = JSON.parse(atob(payload.replace(/-/g, "+").replace(/_/g, "/")));
    return json?.role ?? null;
  } catch {
    return null;
  }
}

const Sidebar = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const isSmallScreen = () => window.innerWidth < 768;

  const [isMobile, setIsMobile] = useState(isSmallScreen());
  const [isOpen, setIsOpen] = useState(!isSmallScreen()); // open on desktop, closed on mobile
  const [pressedKey, setPressedKey] = useState(null);     // transient clicked design

  // Role
  const role = getRoleFromToken();
  const isAdmin = role === "admin" || role === "superadmin";

  // ---------- Auto-open rules based on route ----------
  const routeInProjects   = /^(\/(landparcellist|taxlist|buildinglist|logs|surveyreturns))/.test(location.pathname);
  const routeInParcels    = /^\/parcel(\/(list|map|import|new|search))?$/.test(location.pathname);
  const routeInWMS        = /^\/geoportal(\/|$)/.test(location.pathname) || /^\/wms(\/|$)/.test(location.pathname);
  const routeInAdmin      = /^\/admin(\/|$)/.test(location.pathname);
  const routeInDashboards = /^\/(ibaan_dashboard|taytay_dashboard)(\/|$)/.test(location.pathname);

  const [submenuOpenProjects,   setSubmenuOpenProjects]   = useState(routeInProjects);
  const [submenuOpenParcels,    setSubmenuOpenParcels]    = useState(routeInParcels);
  const [submenuOpenWMS,        setSubmenuOpenWMS]        = useState(routeInWMS);
  const [submenuOpenAdmin,      setSubmenuOpenAdmin]      = useState(routeInAdmin);
  const [submenuOpenDashboards, setSubmenuOpenDashboards] = useState(routeInDashboards);

  useEffect(() => setSubmenuOpenProjects(routeInProjects),   [routeInProjects]);
  useEffect(() => setSubmenuOpenParcels(routeInParcels),     [routeInParcels]);
  useEffect(() => setSubmenuOpenWMS(routeInWMS),             [routeInWMS]);
  useEffect(() => setSubmenuOpenAdmin(routeInAdmin),         [routeInAdmin]);
  useEffect(() => setSubmenuOpenDashboards(routeInDashboards), [routeInDashboards]);

  // ---------- Resize handling ----------
  useEffect(() => {
    const onResize = () => {
      const mobile = isSmallScreen();
      setIsMobile(mobile);
      setIsOpen(!mobile);
    };
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);

  // ---------- Nav helpers ----------
  const onNavigate = useCallback(
    (to, key) => (e) => {
      // allow NavLink to handle routing; also support manual navigate()
      setPressedKey(key);
      setTimeout(() => setPressedKey(null), 160);
      if (to) navigate(to);
      if (isMobile) setIsOpen(false);
    },
    [isMobile, navigate]
  );

  const handleLogout = (e) => {
    e.preventDefault();
    localStorage.removeItem("token");
    sessionStorage.removeItem("token");
    window.location = "/";
  };

  const navClass = ({ isActive }) => "nav-link" + (isActive ? " active fw-semibold" : "");
  const collapsedClass = !isMobile && !isOpen ? "is-collapsed" : "";

  return (
    <>
      {/* Burger (mobile) */}
      {isMobile && (
        <button
          className="burger-btn btn"
          onClick={() => setIsOpen((s) => !s)}
          aria-label="Toggle mobile sidebar"
        >
          <i className="bi bi-list" style={{ fontSize: "1.5rem" }} />
        </button>
      )}

      {/* Sidebar */}
      <div
        className={`Sidebar ${isMobile ? (isOpen ? "sidebar-show" : "sidebar-hide") : ""} ${collapsedClass}`}
        style={{ position: isMobile ? "fixed" : "relative", top: 0, left: 0, zIndex: 2000 }}
      >
        <div
          className="d-flex flex-column frame"
          style={{ width: isOpen ? `${OPEN_W}px` : isMobile ? `${OPEN_W}px` : `${COLLAPSED_W}px` }}
        >
          {/* Desktop collapse toggle */}
          {!isMobile && (
            <button
              className="btn btn-link nav-link"
              style={{ margin: "10px 10px 0 10px", justifyContent: "center" }}
              onClick={() => setIsOpen((s) => !s)}
              aria-label="Toggle sidebar"
              title={isOpen ? "Collapse" : "Expand"}
            >
              <i className={`bi ${isOpen ? "bi-chevron-left" : "bi-chevron-right"}`} />
            </button>
          )}

          {/* Scrollable area */}
          <div className="sidebar-scroll flex-grow-1" style={{ minHeight: 0 }}>
            <nav className="nav flex-column">
              {/* ===== Quick Links (optional) ===== */}
              <NavLink
                to="/taytay_dashboard"
                title="Dashboard"
                className={(s) => navClass(s) + (pressedKey === "taytay_dashboard_quick" ? " is-pressed" : "")}
                onClick={onNavigate("/taytay_dashboard", "taytay_dashboard_quick")}
              >
                <i className="bi bi-house me-2" />
                {isOpen && <span>Dashboard</span>}
              </NavLink>

              <NavLink
                to="/taxpayer"
                title="Taxpayer Dashboard"
                className={(s) => navClass(s) + (pressedKey === "taxpayer" ? " is-pressed" : "")}
                onClick={onNavigate("/taxpayer", "taxpayer")}
              >
                <i className="bi bi-book me-2" />
                {isOpen && <span>Taxpayer Dashboard</span>}
              </NavLink>

              {/* ===== Dashboard (Dropdown) ===== */}
              <button
                className="nav-link btn btn-link text-start d-flex align-items-center"
                onClick={() => setSubmenuOpenDashboards((s) => !s)}
                aria-expanded={submenuOpenDashboards}
                aria-controls="submenu-dashboards"
              >
                <i className="bi bi-speedometer2" />
                {isOpen && <span className="flex-grow-1">Dashboards</span>}
                {isOpen && (
                  <i
                    className={`bi ms-auto ${submenuOpenDashboards ? "bi-caret-up-fill" : "bi-caret-down-fill"}`}
                  />
                )}
              </button>

              <Collapse in={submenuOpenDashboards}>
                <div id="submenu-dashboards" className="ms-2">
                  <NavLink
                    to="/ibaan_dashboard"
                    title="Ibaan Dashboard"
                    className={(s) => navClass(s) + (pressedKey === "ibaan_dashboard" ? " is-pressed" : "")}
                    onClick={onNavigate("/ibaan_dashboard", "ibaan_dashboard")}
                  >
                    <i className="bi bi-speedometer2" />
                    {isOpen && <span>Ibaan Dashboard</span>}
                  </NavLink>

                  <NavLink
                    to="/taytay_dashboard"
                    title="Taytay Dashboard"
                    className={(s) => navClass(s) + (pressedKey === "taytay_dashboard" ? " is-pressed" : "")}
                    onClick={onNavigate("/taytay_dashboard", "taytay_dashboard")}
                  >
                    <i className="bi bi-speedometer" />
                    {isOpen && <span>Taytay Dashboard</span>}
                  </NavLink>
                </div>
              </Collapse>

              {/* ===== Admin (visible only if admin/superadmin) ===== */}
              {isAdmin && (
                <>
                  <button
                    className="nav-link btn btn-link text-start d-flex align-items-center"
                    onClick={() => setSubmenuOpenAdmin((s) => !s)}
                    aria-expanded={submenuOpenAdmin}
                    aria-controls="submenu-admin"
                  >
                    <i className="bi bi-shield-lock" />
                    {isOpen && <span className="flex-grow-1">Admin</span>}
                    {isOpen && (
                      <i
                        className={`bi ms-auto ${
                          submenuOpenAdmin ? "bi-caret-up-fill" : "bi-caret-down-fill"
                        }`}
                      />
                    )}
                  </button>

                  <Collapse in={submenuOpenAdmin}>
                    <div id="submenu-admin" className="ms-2">
                      <NavLink
                        to="/admin/dashboard"
                        title="Admin Dashboard"
                        className={(s) => navClass(s) + (pressedKey === "admin_dashboard" ? " is-pressed" : "")}
                        onClick={onNavigate("/admin/dashboard", "admin_dashboard")}
                      >
                        <i className="bi bi-speedometer2" />
                        {isOpen && <span>Admin Dashboard</span>}
                      </NavLink>

                      <NavLink
                        to="/admin/users"
                        title="Users"
                        className={(s) => navClass(s) + (pressedKey === "admin_users" ? " is-pressed" : "")}
                        onClick={onNavigate("/admin/users", "admin_users")}
                      >
                        <i className="bi bi-people" />
                        {isOpen && <span>Users</span>}
                      </NavLink>
                    </div>
                  </Collapse>
                </>
              )}

              {/* ===== Parcels (Dropdown) ===== */}
              <button
                className="nav-link btn btn-link text-start d-flex align-items-center"
                onClick={() => setSubmenuOpenParcels((s) => !s)}
                aria-expanded={submenuOpenParcels}
                aria-controls="submenu-parcels"
              >
                <i className="bi bi-backpack3" />
                {isOpen && <span className="flex-grow-1">Parcels</span>}
                {isOpen && (
                  <i className={`bi ms-auto ${submenuOpenParcels ? "bi-caret-up-fill" : "bi-caret-down-fill"}`} />
                )}
              </button>

              <Collapse in={submenuOpenParcels}>
                <div id="submenu-parcels" className="ms-2">
                  <NavLink
                    to="/taytay"
                    title="Taytay"
                    className={(s) => navClass(s) + (pressedKey === "taytay" ? " is-pressed" : "")}
                    onClick={onNavigate("/taytay", "taytay")}
                  >
                    <i className="bi bi-geo" />
                    {isOpen && <span>Taytay</span>}
                  </NavLink>

                  <NavLink
                    to="/map"
                    title="Ibaan"
                    className={(s) => navClass(s) + (pressedKey === "map" ? " is-pressed" : "")}
                    onClick={onNavigate("/map", "map")}
                  >
                    <i className="bi bi-geo-alt" />
                    {isOpen && <span>Ibaan</span>}
                  </NavLink>

                  <NavLink
                    to="/parcel"
                    title="Search Parcel"
                    className={(s) => navClass(s) + (pressedKey === "parcel" ? " is-pressed" : "")}
                    onClick={onNavigate("/parcel", "parcel")}
                  >
                    <i className="bi bi-search" />
                    {isOpen && <span>Search Parcel</span>}
                  </NavLink>
                </div>
              </Collapse>

              {/* ===== Web Map Services (Dropdown) ===== */}
              <button
                className="nav-link btn btn-link text-start d-flex align-items-center"
                onClick={() => setSubmenuOpenWMS((s) => !s)}
                aria-expanded={submenuOpenWMS}
                aria-controls="submenu-wms"
              >
                <i className="bi bi-layers" />
                {isOpen && <span className="flex-grow-1">Web Map Services</span>}
                {isOpen && (
                  <i className={`bi ms-auto ${submenuOpenWMS ? "bi-caret-up-fill" : "bi-caret-down-fill"}`} />
                )}
              </button>

              <Collapse in={submenuOpenWMS}>
                <div id="submenu-wms" className="ms-2">
                  <NavLink
                    to="/geoportal"
                    title="Geoportal"
                    className={(s) => navClass(s) + (pressedKey === "geoportal" ? " is-pressed" : "")}
                    onClick={onNavigate("/geoportal", "geoportal")}
                  >
                    <i className="bi bi-grid" />
                    {isOpen && <span>Geoportal</span>}
                  </NavLink>
                </div>
              </Collapse>

              {/* ===== Projects (Dropdown) ===== */}
              <button
                className="nav-link btn btn-link text-start d-flex align-items-center"
                onClick={() => setSubmenuOpenProjects((s) => !s)}
                aria-expanded={submenuOpenProjects}
                aria-controls="submenu-projects"
              >
                <i className="bi bi-folder" />
                {isOpen && <span className="flex-grow-1">Projects</span>}
                {isOpen && (
                  <i className={`bi ms-auto ${submenuOpenProjects ? "bi-caret-up-fill" : "bi-caret-down-fill"}`} />
                )}
              </button>

              <Collapse in={submenuOpenProjects}>
                <div id="submenu-projects" className="ms-2">
                  <NavLink
                    to="/landparcellist"
                    title="Land Parcels"
                    className={(s) => navClass(s) + (pressedKey === "landparcellist" ? " is-pressed" : "")}
                    onClick={onNavigate("/landparcellist", "landparcellist")}
                  >
                    <i className="bi bi-geo" />
                    {isOpen && <span>Land Parcels</span>}
                  </NavLink>

                  <NavLink
                    to="/taxlist"
                    title="Tax Forms"
                    className={(s) => navClass(s) + (pressedKey === "taxlist" ? " is-pressed" : "")}
                    onClick={onNavigate("/taxlist", "taxlist")}
                  >
                    <i className="bi bi-receipt" />
                    {isOpen && <span>Tax Forms</span>}
                  </NavLink>

                  <NavLink
                    to="/buildinglist"
                    title="Buildings"
                    className={(s) => navClass(s) + (pressedKey === "buildinglist" ? " is-pressed" : "")}
                    onClick={onNavigate("/buildinglist", "buildinglist")}
                  >
                    <i className="bi bi-building" />
                    {isOpen && <span>Buildings</span>}
                  </NavLink>

                  <NavLink
                    to="/surveyreturns"
                    title="Survey Returns"
                    className={(s) => navClass(s) + (pressedKey === "surveyreturns" ? " is-pressed" : "")}
                    onClick={onNavigate("/surveyreturns", "surveyreturns")}
                  >
                    <i className="bi bi-journal-text" />
                    {isOpen && <span>Survey Returns</span>}
                  </NavLink>

                  <NavLink
                    to="/logs"
                    title="Logs"
                    className={(s) => navClass(s) + (pressedKey === "logs" ? " is-pressed" : "")}
                    onClick={onNavigate("/logs", "logs")}
                  >
                    <i className="bi bi-clipboard-data" />
                    {isOpen && <span>Logs</span>}
                  </NavLink>
                </div>
              </Collapse>

              {/* ===== Settings / Logout ===== */}
              <NavLink
                to="/settings"
                title="Settings"
                className={(s) => navClass(s) + (pressedKey === "settings" ? " is-pressed" : "")}
                onClick={onNavigate("/settings", "settings")}
              >
                <i className="bi bi-gear" />
                {isOpen && <span>Settings</span>}
              </NavLink>

              <a
                href="#logout"
                title="Logout"
                className={"nav-link mt-auto" + (pressedKey === "logout" ? " is-pressed" : "")}
                onClick={(e) => {
                  setPressedKey("logout");
                  setTimeout(() => setPressedKey(null), 160);
                  handleLogout(e);
                }}
              >
                <i className="bi bi-box-arrow-right" />
                {isOpen && <span>Logout</span>}
              </a>
            </nav>
          </div>
        </div>
      </div>
    </>
  );
};

export default Sidebar;
