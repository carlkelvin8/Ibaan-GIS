import React, { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import Table from "react-bootstrap/Table";
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";
import Modal from "react-bootstrap/Modal";
import Badge from "react-bootstrap/Badge";
import Spinner from "react-bootstrap/Spinner";
import { diffLines } from "diff";
import api from "../../lib/axios.js";

const PAGE_SIZE = 20;

/** ---------------- helpers ---------------- **/
const safeParse = (v) => {
  if (!v) return null;
  if (typeof v === "object") return v;
  try {
    return JSON.parse(v);
  } catch {
    return null;
  }
};

const formatDT = (v) => (v ? new Date(v).toLocaleString() : "—");

// Turn keys into friendly labels (ParcelId -> Parcel ID, etc.)
const HUMAN_LABEL_MAP = {
  ParcelId: "Parcel ID",
  parcelId: "Parcel ID",
  parcelID: "Parcel ID",
  LotNumber: "Lot Number",
  BarangayNa: "Barangay",
  arpNo: "ARP No",
  taxId: "Tax ID",
  user_agent: "User Agent",
};
const humanizeKey = (k = "") => {
  if (HUMAN_LABEL_MAP[k]) return HUMAN_LABEL_MAP[k];
  return String(k)
    .replace(/([a-z0-9])([A-Z])/g, "$1 $2")
    .replace(/_/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .replace(/\bId\b/g, "ID")
    .replace(/\bNo\b/g, "No");
};

// Format any JS value to human string (no quotes/braces)
const fmt = (val) => {
  if (val == null || val === "") return "—";
  if (typeof val === "boolean") return val ? "Yes" : "No";
  if (typeof val === "number") return val.toLocaleString();
  if (typeof val === "string") return val.trim();
  if (Array.isArray(val)) return val.length ? val.map(fmt).join(", ") : "—";
  // object handled by plainify recursion
  return "";
};

// FULL plain text (no JSON look) for any object/array/string
const plainify = (input) => {
  const v = safeParse(input) ?? input;
  const lines = [];
  const walk = (x, indent = "") => {
    if (x == null) return;
    if (typeof x !== "object") {
      lines.push(`${indent}${fmt(x)}`);
      return;
    }
    if (Array.isArray(x)) {
      if (!x.length) {
        lines.push(`${indent}—`);
        return;
      }
      x.forEach((item, idx) => {
        if (typeof item === "object" && item !== null) {
          lines.push(`${indent}• Item ${idx + 1}`);
          walk(item, indent + "  ");
        } else {
          lines.push(`${indent}• ${fmt(item)}`);
        }
      });
      return;
    }
    // object
    const keys = Object.keys(x);
    if (!keys.length) {
      lines.push(`${indent}—`);
      return;
    }
    keys.forEach((k) => {
      const label = humanizeKey(k);
      const val = x[k];
      if (val && typeof val === "object") {
        lines.push(`${indent}${label}`);
        walk(val, indent + "  ");
      } else {
        lines.push(`${indent}${label} — ${fmt(val)}`);
      }
    });
  };
  walk(v, "");
  return lines.join("\n");
};

/** ---------- Unified diff that uses plainified text ---------- **/
function UnifiedDiff({ before, after }) {
  const beforeStr = useMemo(
    () => plainify(safeParse(before) ?? before ?? ""),
    [before]
  );
  const afterStr = useMemo(
    () => plainify(safeParse(after) ?? after ?? ""),
    [after]
  );

  const parts = useMemo(
    () => diffLines(beforeStr, afterStr, { newlineIsToken: false }),
    [beforeStr, afterStr]
  );

  const lineBase = {
    fontFamily:
      "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace",
    whiteSpace: "pre-wrap",
    margin: 0,
    padding: "2px 10px",
    borderRadius: 4,
    lineHeight: 1.35,
  };

  const styles = {
    added: {
      ...lineBase,
      background: "#e6ffed",
      color: "#1a7f37",
      border: "1px solid #b5e0c7",
    },
    removed: {
      ...lineBase,
      background: "#ffeef0",
      color: "#82071e",
      border: "1px solid #f2c1c3",
    },
    neutral: {
      ...lineBase,
      background: "#f6f8fa",
      color: "#24292f",
      border: "1px solid #e1e4e8",
    },
    lineWrap: {
      maxHeight: 360,
      overflow: "auto",
      border: "1px solid #e1e4e8",
      borderRadius: 6,
      background: "#fff",
    },
    legendBadge: {
      fontFamily:
        "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace",
      fontSize: 12,
    },
  };

  const renderLines = (value, type) => {
    const lines =
      value && value.endsWith("\n")
        ? value.slice(0, -1).split("\n")
        : (value || "").split("\n");
    return lines.map((l, i) => {
      const isAdded = type === "added";
      const isRemoved = type === "removed";
      const style = isAdded ? styles.added : isRemoved ? styles.removed : styles.neutral;
      const prefix = isAdded ? "+" : isRemoved ? "-" : " ";
      return (
        <div key={`${type}-${i}`} style={style}>
          {prefix} {l.length ? l : "\u00A0"}
        </div>
      );
    });
  };

  return (
    <div>
      <div className="d-flex gap-2 align-items-center mb-2">
        <span className="badge text-bg-success" style={styles.legendBadge}>
          + added
        </span>
        <span className="badge text-bg-danger" style={styles.legendBadge}>
          - removed
        </span>
        <span className="badge text-bg-secondary" style={styles.legendBadge}>
          context
        </span>
      </div>

      <div style={styles.lineWrap}>
        {parts.flatMap((p, idx) => {
          if (p.added) return renderLines(p.value, "added");
          if (p.removed) return renderLines(p.value, "removed");
          return renderLines(p.value, "neutral");
        })}
      </div>
    </div>
  );
}

/** ---------------- page ---------------- **/
export default function Logs() {
  const navigate = useNavigate();

  // data
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState(null);

  // filters
  const [q, setQ] = useState("");
  const [username, setUsername] = useState("");
  const [entityType, setEntityType] = useState("");
  const [action, setAction] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [sort, setSort] = useState("created_at_desc");

  // paging
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(null);

  // details modal
  const [show, setShow] = useState(false);
  const [active, setActive] = useState(null);

  const canPrev = page > 1;
  const canNext =
    rows.length === PAGE_SIZE || (total != null && page * PAGE_SIZE < total);

  const fetchLogs = async () => {
    setLoading(true);
    setErr(null);
    try {
      const params = {
        page,
        limit: PAGE_SIZE,
        q: q || undefined,
        username: username || undefined,
        entity_type: entityType || undefined,
        action: action || undefined,
        from: from || undefined,
        to: to || undefined,
        sort,
      };

      const res = await api.get("/audit-logs", { params });

      // handle various shapes
      let data = res.data;
      let list = [];
      let totalCount = null;

      if (Array.isArray(data)) {
        list = data;
      } else if (data?.data && Array.isArray(data.data)) {
        list = data.data;
        totalCount = data.total ?? data.count ?? data.meta?.total ?? null;
      } else if (data?.rows && Array.isArray(data.rows)) {
        list = data.rows;
        totalCount = data.total ?? data.count ?? data.meta?.total ?? null;
      }

      if (totalCount == null) {
        const h = res.headers?.["x-total-count"];
        if (h && !Number.isNaN(Number(h))) totalCount = Number(h);
      }

      setRows(list);
      setTotal(totalCount);
    } catch (e) {
      console.error(e);
      setErr("Failed to fetch audit logs.");
      setRows([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLogs();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [page, sort]);

  const applyFilters = (e) => {
    e?.preventDefault?.();
    setPage(1);
    fetchLogs();
  };

  const resetFilters = () => {
    setQ("");
    setUsername("");
    setEntityType("");
    setAction("");
    setFrom("");
    setTo("");
    setSort("created_at_desc");
    setPage(1);
    fetchLogs();
  };

  const openDetails = (row) => {
    setActive(row);
    setShow(true);
  };

  const closeDetails = () => {
    setShow(false);
    setActive(null);
  };

  // quick opens based on entity type/id/context
  const openEntity = (row) => {
    const ctx = safeParse(row?.entity_ctx) || row?.entity_ctx || {};
    const type = row?.entity_type?.toLowerCase?.() || "";
    const eid = row?.entity_id;

    if (type === "tax_forms") {
      const taxId = eid || ctx?.id || ctx?.taxId;
      if (taxId) {
        localStorage.setItem("taxId", String(taxId));
        navigate("/taxform");
      } else {
        alert("No tax ID present in this log entry.");
      }
      return;
    }

    let parcelId = ctx?.ParcelId ?? ctx?.parcelId ?? ctx?.parcelID ?? eid;

    if (!parcelId) {
      const before = safeParse(row?.before_data) || {};
      const after = safeParse(row?.after_data) || {};
      parcelId =
        before.ParcelId ||
        before.parcelId ||
        after.ParcelId ||
        after.parcelId ||
        null;
    }

    if (parcelId) {
      navigate(`/${encodeURIComponent(String(parcelId))}`);
    } else {
      alert("No ParcelId/parcelID available for this log entry.");
    }
  };

  const summaryCtx = (row) => {
    const ctx = safeParse(row?.entity_ctx) || row?.entity_ctx || {};
    const parts = [];
    if (ctx.ParcelId) parts.push(`PID:${ctx.ParcelId}`);
    if (ctx.LotNumber) parts.push(`Lot:${ctx.LotNumber}`);
    if (ctx.BarangayNa) parts.push(`Brgy:${ctx.BarangayNa}`);
    if (ctx.arpNo) parts.push(`ARP:${ctx.arpNo}`);
    if (!parts.length && row?.entity_id) parts.push(`ID:${row.entity_id}`);
    return parts.join("  •  ");
  };

  const changedList = (row) => {
    const c = safeParse(row?.changed_fields);
    if (!c || !Array.isArray(c) || !c.length) return null;
    return c;
  };

  const entityLabel = (row) => {
    const t = row?.entity_type || "—";
    const id = row?.entity_id || "—";
    return `${t} / ${id}`;
  };

  const headerInfo = useMemo(() => {
    if (total == null) {
      const start = (page - 1) * PAGE_SIZE + 1;
      const end = start + rows.length - 1;
      return rows.length ? `${start}–${end}` : "0";
    }
    const start = (page - 1) * PAGE_SIZE + 1;
    const end = Math.min(page * PAGE_SIZE, total);
    return total ? `${start}–${end} of ${total}` : "0";
  }, [page, rows.length, total]);

  return (
    <div className="container mt-4">
      <h2 className="mb-3">Audit Logs</h2>

      {/* Filters */}
      <Form onSubmit={applyFilters} className="row g-2 mb-3">
        <div className="col-md-3">
          <Form.Control
            placeholder="Search (user, entity, id, context)…"
            value={q}
            onChange={(e) => setQ(e.target.value)}
          />
        </div>
        <div className="col-md-2">
          <Form.Control
            placeholder="Username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
        </div>
        <div className="col-md-2">
          <Form.Control
            placeholder="Entity type (e.g., ibaan)"
            value={entityType}
            onChange={(e) => setEntityType(e.target.value)}
          />
        </div>
        <div className="col-md-2">
          <Form.Select
            value={action}
            onChange={(e) => setAction(e.target.value)}
          >
            <option value="">Any action</option>
            <option value="CREATE">CREATE</option>
            <option value="UPDATE">UPDATE</option>
            <option value="DELETE">DELETE</option>
          </Form.Select>
        </div>
        <div className="col-md-3 d-flex gap-2">
          <Form.Control
            type="date"
            value={from}
            onChange={(e) => setFrom(e.target.value)}
            title="From date"
          />
          <Form.Control
            type="date"
            value={to}
            onChange={(e) => setTo(e.target.value)}
            title="To date"
          />
        </div>
        <div className="col-12 d-flex gap-2 align-items-center">
          <Form.Select
            style={{ maxWidth: 220 }}
            value={sort}
            onChange={(e) => setSort(e.target.value)}
            title="Sort"
          >
            <option value="created_at_desc">Newest first</option>
            <option value="created_at_asc">Oldest first</option>
          </Form.Select>
          <Button type="submit" variant="primary">
            Apply
          </Button>
          <Button
            type="button"
            variant="outline-secondary"
            onClick={resetFilters}
          >
            Reset
          </Button>
          <div className="ms-auto text-muted small">{headerInfo}</div>
        </div>
      </Form>

      {/* Table */}
      <div className="position-relative">
        {loading && (
          <div
            className="d-flex align-items-center justify-content-center"
            style={{
              position: "absolute",
              inset: 0,
              background: "rgba(255,255,255,.6)",
              zIndex: 2,
            }}
          >
            <Spinner animation="border" role="status" />
          </div>
        )}

        {err && <div className="alert alert-danger">{err}</div>}

        <Table striped bordered hover responsive>
          <thead>
            <tr>
              <th style={{ minWidth: 170 }}>Time</th>
              <th>User</th>
              <th>Action</th>
              <th>Entity</th>
              <th>Context</th>
              <th>Changed</th>
              <th style={{ width: 180 }}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 ? (
              <tr>
                <td colSpan={7} className="text-center text-muted">
                  No logs found.
                </td>
              </tr>
            ) : (
              rows.map((r) => {
                const changes = changedList(r);
                return (
                  <tr key={r.id}>
                    <td>{formatDT(r.created_at)}</td>
                    <td>{r.username || "—"}</td>
                    <td>
                      <Badge
                        bg={
                          r.action === "CREATE"
                            ? "success"
                            : r.action === "UPDATE"
                            ? "warning"
                            : r.action === "DELETE"
                            ? "danger"
                            : "secondary"
                        }
                      >
                        {r.action || "—"}
                      </Badge>
                    </td>
                    <td>{entityLabel(r)}</td>
                    <td className="text-truncate" style={{ maxWidth: 260 }}>
                      {summaryCtx(r)}
                    </td>
                    <td>
                      {changes?.length ? (
                        <div className="d-flex flex-wrap gap-1">
                          {changes.slice(0, 6).map((f) => (
                            <Badge key={f} bg="light" text="dark">
                              {humanizeKey(f)}
                            </Badge>
                          ))}
                          {changes.length > 6 && (
                            <Badge bg="secondary">
                              +{changes.length - 6}
                            </Badge>
                          )}
                        </div>
                      ) : (
                        <span className="text-muted">—</span>
                      )}
                    </td>
                    <td>
                      <div className="d-flex flex-wrap gap-2">
                        <Button
                          size="sm"
                          variant="outline-primary"
                          onClick={() => openDetails(r)}
                        >
                          Details
                        </Button>
                        <Button
                          size="sm"
                          variant="secondary"
                          onClick={() => openEntity(r)}
                        >
                          View on Map
                        </Button>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </Table>
      </div>

      {/* Pager */}
      <div className="d-flex justify-content-between align-items-center">
        <div className="text-muted small">
          Page {page}
          {total != null ? ` · Total ${total}` : ""}
        </div>
        <div className="d-flex gap-2">
          <Button
            variant="outline-secondary"
            size="sm"
            disabled={!canPrev}
            onClick={() => setPage((p) => Math.max(1, p - 1))}
          >
            ‹ Prev
          </Button>
          <Button
            variant="outline-secondary"
            size="sm"
            disabled={!canNext}
            onClick={() => setPage((p) => p + 1)}
          >
            Next ›
          </Button>
        </div>
      </div>

      {/* Details Modal */}
      <Modal show={!!show} onHide={closeDetails} size="lg">
        <Modal.Header closeButton>
          <Modal.Title>Log Details</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {active ? (
            <>
              {/* Summary */}
              <div className="mb-3">
                <div><strong>Time</strong> <span className="ms-2">{formatDT(active.created_at)}</span></div>
                <div><strong>User</strong> <span className="ms-2">{active.username || "—"}</span></div>
                <div><strong>Action</strong> <span className="ms-2">{active.action || "—"}</span></div>
                <div><strong>Entity</strong> <span className="ms-2">{entityLabel(active)}</span></div>
                {active.ip ? <div><strong>IP</strong> <span className="ms-2">{active.ip}</span></div> : null}
                {active.user_agent ? (
                  <div className="text-break">
                    <strong>User Agent</strong> <span className="ms-2">{active.user_agent}</span>
                  </div>
                ) : null}
              </div>

              <hr />

              {/* Context (FULL, non-JSON look) */}
              <div className="mb-3">
                <h6 className="mb-2">Context</h6>
                <pre
                  className="bg-light p-2 rounded border"
                  style={{ maxHeight: 220, overflow: "auto", fontFamily: "system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif" }}
                >
{plainify(safeParse(active.entity_ctx) ?? active.entity_ctx)}
                </pre>
              </div>

              {/* Changed fields */}
              <div className="mb-3">
                <h6 className="mb-2">Changed Fields</h6>
                {(() => {
                  const c = safeParse(active?.changed_fields);
                  const changed = c && Array.isArray(c) ? c : null;
                  return changed?.length ? (
                    <div className="d-flex flex-wrap gap-2">
                      {changed.map((f) => (
                        <Badge key={f} bg="light" text="dark">
                          {humanizeKey(f)}
                        </Badge>
                      ))}
                    </div>
                  ) : (
                    <div className="text-muted">—</div>
                  );
                })()}
              </div>

              {/* Diff (plainified) */}
              <div className="mb-1 d-flex align-items-center gap-2">
                <h6 className="mb-0">Changes</h6>
              </div>
              <UnifiedDiff before={active.before_data} after={active.after_data} />
            </>
          ) : (
            <div className="text-muted">No data.</div>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={closeDetails}>Close</Button>
          {active && (
            <Button variant="primary" onClick={() => openEntity(active)}>
              View on Map
            </Button>
          )}
        </Modal.Footer>
      </Modal>
    </div>
  );
}
