
import './Header.css'

const Header = () => {
  return (
    <>
      <header className="Header">
        <h2>CVGeoSpatial</h2>
      </header>
    </>
  );
};

export default Header;
