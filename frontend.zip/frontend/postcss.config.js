export default {
  plugins: {
  
    autoprefixer: {},
  },
}
