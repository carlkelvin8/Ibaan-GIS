// src/controllers/userController.js
import { database } from '../config/database.js';
import bcrypt from 'bcryptjs';
import dotenv from 'dotenv';
import jwt from 'jsonwebtoken';

dotenv.config();

/* =========================
   Constants / helpers
   ========================= */
const ROLES = new Set(['ADMIN', 'ASSESSOR', 'ENGINEER', 'PLANNER', 'BPLO']);
// Legacy acceptors (para di sumabog habang transition)
const LEGACY_ADMIN = new Set(['admin', 'superadmin', '1']);

const STATUSES = new Set(['active', 'pending', 'disabled']);

function normalizeRole(role) {
  if (role == null || role === '') return null;
  const r = String(role).trim();
  const upper = r.toUpperCase();
  if (ROLES.has(upper)) return upper;
  // legacy mapping (optional)
  if (LEGACY_ADMIN.has(r.toLowerCase())) return 'ADMIN';
  return null; // invalid
}

function normalizeStatus(status) {
  if (status == null || status === '') return null;
  const s = String(status).trim().toLowerCase();
  if (STATUSES.has(s)) return s;
  // numeric legacy (optional)
  if (s === '1') return 'active';
  if (s === '0') return 'pending';
  if (s === '-1') return 'disabled';
  return null;
}

function safeInt(v) {
  const n = parseInt(v, 10);
  return Number.isFinite(n) ? n : null;
}

/* =========================
   AUTH (signup/login)
   ========================= */

export async function signup(req, res) {
  try {
    const { username, first_name, last_name, email, password } = req.body;

    // Default role/status for self-signup (pwede mong i-adjust):
    const role = 'BPLO';
    const status = 'pending';

    // Check duplicates
    const [existing] = await database.execute(
      `SELECT id, username, email FROM users WHERE username = ? OR email = ? LIMIT 1`,
      [username, email]
    );
    if (existing.length > 0) {
      return res.status(400).json({
        result: 0,
        error:
          existing[0].username === username
            ? 'Username already exists'
            : 'Email already exists',
      });
    }

    const hash = await bcrypt.hash(password, 10);
    await database.execute(
      `INSERT INTO users
        (username, first_name, last_name, email, password, role, status, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NOW())`,
      [username, first_name, last_name, email, hash, role, status]
    );

    return res.status(201).json({ result: 1, message: 'User registered successfully' });
  } catch (err) {
    console.error('[signup]', err);
    return res.status(500).json({ result: 0, error: err.message });
  }
}

export async function login(req, res) {
  try {
    const { username, password } = req.body;
    const JWT_SECRET = process.env.JWT_SECRET;

    // Allow username OR email
    const [rows] = await database.execute(
      `SELECT * FROM users WHERE (username = ? OR email = ?) AND deleted_at IS NULL LIMIT 1`,
      [username, username]
    );
    if (rows.length === 0) {
      return res.status(401).json({ result: 0, error: 'User not found' });
    }

    const user = rows[0];
    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.status(401).json({ result: 0, error: 'Invalid credentials' });

    const token = jwt.sign(
      { id: user.id, username: user.username, role: user.role },
      JWT_SECRET,
      { expiresIn: '8h' } // mas mahaba for dev; adjust as needed
    );

    const { password: _pw, ...safeUser } = user;
    return res.json({ result: 1, message: 'Login successful', token, user: safeUser });
  } catch (err) {
    console.error('[login]', err);
    return res.status(500).json({ result: 0, error: err.message });
  }
}

/* =========================
   CREATE
   POST /api/admin/users
   Body: { username, first_name, last_name, email, password, role, status, office_id?, municipality_id? }
   ========================= */
export async function createUser(req, res) {
  try {
    const {
      username,
      first_name,
      last_name,
      email,
      password,
      role,
      status,
      office_id,
      municipality_id,
    } = req.body;

    if (!username || !first_name || !last_name || !email || !password) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const roleNorm = normalizeRole(role) || 'BPLO';
    const statusNorm = normalizeStatus(status) || 'pending';

    // Uniq checks
    const [dup] = await database.execute(
      `SELECT id, username, email FROM users WHERE (username = ? OR email = ?) AND deleted_at IS NULL LIMIT 1`,
      [username, email]
    );
    if (dup.length) {
      return res.status(409).json({
        error:
          dup[0].username === username ? 'Username already exists' : 'Email already exists',
      });
    }

    const hash = await bcrypt.hash(password, 10);
    const [result] = await database.execute(
      `INSERT INTO users
        (username, first_name, last_name, email, password, role, status, office_id, municipality_id, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())`,
      [
        username,
        first_name,
        last_name,
        email,
        hash,
        roleNorm,
        statusNorm,
        office_id ?? null,
        municipality_id ?? null,
      ]
    );

    const newId = result.insertId;
    const [rows] = await database.execute(
      `SELECT id, username, first_name, last_name, email, role, status, office_id, municipality_id, created_at, updated_at
       FROM users WHERE id = ?`,
      [newId]
    );

    return res.status(201).json({ data: rows[0] });
  } catch (err) {
    console.error('[createUser]', err);
    return res.status(500).json({ error: err.message });
  }
}

/* =========================
   READ ONE
   GET /api/admin/users/:id
   ========================= */
export async function getUserById(req, res) {
  try {
    const id = safeInt(req.params.id);
    if (!id) return res.status(400).json({ error: 'Invalid id' });

    const [rows] = await database.execute(
      `SELECT id, username, first_name, last_name, email, role, status, office_id, municipality_id, created_at, updated_at
       FROM users
       WHERE id = ? AND deleted_at IS NULL`,
      [id]
    );
    if (!rows.length) return res.status(404).json({ error: 'User not found' });

    return res.json({ data: rows[0] });
  } catch (err) {
    console.error('[getUserById]', err);
    return res.status(500).json({ error: err.message });
  }
}

/* =========================
   UPDATE
   PATCH /api/admin/users/:id
   Body: { first_name?, last_name?, email?, password?, role?, status?, office_id?, municipality_id? }
   ========================= */
export async function updateUser(req, res) {
  try {
    const id = safeInt(req.params.id);
    if (!id) return res.status(400).json({ error: 'Invalid id' });

    // load existing
    const [curRows] = await database.execute(
      `SELECT * FROM users WHERE id = ? AND deleted_at IS NULL LIMIT 1`,
      [id]
    );
    if (!curRows.length) return res.status(404).json({ error: 'User not found' });
    const current = curRows[0];

    const {
      first_name = current.first_name,
      last_name = current.last_name,
      email = current.email,
      password, // optional (hash if present)
      role = current.role,
      status = current.status,
      office_id = current.office_id,
      municipality_id = current.municipality_id,
    } = req.body || {};

    // normalize role/status
    const roleNorm = normalizeRole(role) || current.role;
    const statusNorm = normalizeStatus(status) || current.status;

    // duplicate email check if changed
    if (email !== current.email) {
      const [dup] = await database.execute(
        `SELECT id FROM users WHERE email = ? AND id <> ? AND deleted_at IS NULL LIMIT 1`,
        [email, id]
      );
      if (dup.length) return res.status(409).json({ error: 'Email already exists' });
    }

    let hash = null;
    if (password && String(password).trim().length >= 6) {
      hash = await bcrypt.hash(password, 10);
    }

    // build update SQL dynamically
    const sets = [
      'first_name = ?',
      'last_name = ?',
      'email = ?',
      'role = ?',
      'status = ?',
      'office_id = ?',
      'municipality_id = ?',
      'updated_at = NOW()',
    ];
    const params = [
      first_name,
      last_name,
      email,
      roleNorm,
      statusNorm,
      office_id ?? null,
      municipality_id ?? null,
    ];

    if (hash) {
      sets.splice(3, 0, 'password = ?'); // after email
      params.splice(3, 0, hash);
    }

    params.push(id);

    await database.execute(
      `UPDATE users SET ${sets.join(', ')} WHERE id = ? AND deleted_at IS NULL`,
      params
    );

    const [rows] = await database.execute(
      `SELECT id, username, first_name, last_name, email, role, status, office_id, municipality_id, created_at, updated_at
       FROM users WHERE id = ?`,
      [id]
    );
    return res.json({ data: rows[0] });
  } catch (err) {
    console.error('[updateUser]', err);
    return res.status(500).json({ error: err.message });
  }
}

/* =========================
   DELETE (soft)
   DELETE /api/admin/users/:id
   ========================= */
export async function deleteUser(req, res) {
  try {
    const id = safeInt(req.params.id);
    if (!id) return res.status(400).json({ error: 'Invalid id' });

    const [rows] = await database.execute(
      `SELECT id FROM users WHERE id = ? AND deleted_at IS NULL LIMIT 1`,
      [id]
    );
    if (!rows.length) return res.status(404).json({ error: 'User not found' });

    await database.execute(
      `UPDATE users SET deleted_at = NOW(), updated_at = NOW() WHERE id = ?`,
      [id]
    );
    return res.json({ result: 1, message: 'User deleted' });
  } catch (err) {
    console.error('[deleteUser]', err);
    return res.status(500).json({ error: err.message });
  }
}

/* =========================
   LIST (FILTERED)
   GET /api/admin/users
   ========================= */
/**
 * Query:
 *   q, role, status, officeId, municipalityId, dateFrom, dateTo, page, limit, sort (e.g. -createdAt)
 * Response:
 *   { data, page, limit, total, pages, summary: { total, active, pending, disabled } }
 */
export async function listFilteredUsers(req, res) {
  try {
    const {
      q,
      role,
      status,
      officeId,
      municipalityId,
      dateFrom,
      dateTo,
      page = 1,
      limit = 20,
      sort = '-createdAt',
    } = req.query;

    const _page = Math.max(parseInt(page, 10) || 1, 1);
    const _limit = Math.min(Math.max(parseInt(limit, 10) || 20, 1), 100);
    const offset = (_page - 1) * _limit;

    // sort map
    const SORT_MAP = {
      id: 'u.id',
      username: 'u.username',
      firstName: 'u.first_name',
      lastName: 'u.last_name',
      email: 'u.email',
      role: 'u.role',
      status: 'u.status',
      officeId: 'u.office_id',
      municipalityId: 'u.municipality_id',
      createdAt: 'u.created_at',
      updatedAt: 'u.updated_at',
    };

    let orderBy = 'u.created_at';
    let orderDir = 'DESC';
    if (typeof sort === 'string' && sort.trim()) {
      const raw = sort.trim();
      const desc = raw.startsWith('-');
      const key = desc ? raw.slice(1) : raw;
      if (SORT_MAP[key]) {
        orderBy = SORT_MAP[key];
        orderDir = desc ? 'DESC' : 'ASC';
      }
    }

    // WHERE
    const where = ['u.deleted_at IS NULL'];
    const params = [];

    if (q && String(q).trim()) {
      const like = `%${String(q).trim()}%`;
      where.push(
        `(u.username LIKE ? OR u.email LIKE ? OR u.first_name LIKE ? OR u.last_name LIKE ?)`
      );
      params.push(like, like, like, like);
    }

    const roleNorm = normalizeRole(role);
    if (roleNorm) {
      where.push(`u.role = ?`);
      params.push(roleNorm);
    }

    const statusNorm = normalizeStatus(status);
    if (statusNorm) {
      where.push(`u.status = ?`);
      params.push(statusNorm);
    }

    if (officeId !== undefined && officeId !== '') {
      where.push(`u.office_id = ?`);
      params.push(officeId);
    }

    if (municipalityId !== undefined && municipalityId !== '') {
      where.push(`u.municipality_id = ?`);
      params.push(municipalityId);
    }

    if (dateFrom) {
      where.push(`DATE(u.created_at) >= ?`);
      params.push(dateFrom);
    }
    if (dateTo) {
      where.push(`DATE(u.created_at) <= ?`);
      params.push(dateTo);
    }

    const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';

    // Queries (exclude password; exclude soft-deleted)
    const listSql = `
      SELECT
        u.id, u.username, u.first_name, u.last_name, u.email, u.role, u.status,
        u.office_id, u.municipality_id, u.created_at, u.updated_at
      FROM users u
      ${whereSql}
      ORDER BY ${orderBy} ${orderDir}
      LIMIT ? OFFSET ?
    `;

    const countSql = `
      SELECT COUNT(*) AS total
      FROM users u
      ${whereSql}
    `;

    const summarySql = `
      SELECT
        COUNT(*) AS total,
        SUM(CASE WHEN u.status = 'active'   THEN 1 ELSE 0 END) AS active,
        SUM(CASE WHEN u.status = 'pending'  THEN 1 ELSE 0 END) AS pending,
        SUM(CASE WHEN u.status = 'disabled' THEN 1 ELSE 0 END) AS disabled
      FROM users u
      ${whereSql}
    `;

    const listParams = [...params, _limit, offset];

    const [listRowsP, countRowsP, summaryRowsP] = await Promise.all([
      database.execute(listSql, listParams),
      database.execute(countSql, params),
      database.execute(summarySql, params),
    ]);

    const [listRows] = listRowsP;
    const [countRows] = countRowsP;
    const [summaryRows] = summaryRowsP;

    const total = countRows?.[0]?.total ?? 0;
    const pages = Math.max(Math.ceil(total / _limit), 1);
    const summary = summaryRows?.[0] || { total, active: 0, pending: 0, disabled: 0 };

    res.set('X-Total-Count', String(total));
    return res.json({ data: listRows, page: _page, limit: _limit, total, pages, summary });
  } catch (err) {
    console.error('[listFilteredUsers]', err);
    return res.status(500).json({ error: err.message });
  }
}

/* =========================
   Named exports for router
   ========================= */
export default {
  signup,
  login,
  createUser,
  getUserById,
  updateUser,
  deleteUser,
  listFilteredUsers,
};
