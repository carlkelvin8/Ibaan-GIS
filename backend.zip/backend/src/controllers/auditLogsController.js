// backend/src/controllers/auditLogsController.js
import { database } from "../config/database.js";

const PAGE_DEFAULT = 1;
const LIMIT_DEFAULT = 20;

// Whitelist only these sort options
const SORT_MAP = Object.freeze({
  created_at_desc: "al.created_at DESC",
  created_at_asc: "al.created_at ASC",
});

export async function getAuditLogs(req, res) {
  try {
    /* ------------------------ read & sanitize ------------------------ */
    const page = Math.max(parseInt(req.query.page ?? PAGE_DEFAULT, 10) || 1, 1);
    const limitRaw = parseInt(req.query.limit ?? LIMIT_DEFAULT, 10);
    const limit = Math.min(Math.max(limitRaw || LIMIT_DEFAULT, 1), 200);
    const offset = (page - 1) * limit;

    const q = String(req.query.q ?? "").trim();
    const username = String(req.query.username ?? "").trim();
    const entity_type = String(req.query.entity_type ?? "").trim();
    const action = String(req.query.action ?? "").trim(); // CREATE/UPDATE/DELETE/VIEW/etc.
    const from = String(req.query.from ?? "").trim();     // YYYY-MM-DD
    const to = String(req.query.to ?? "").trim();         // YYYY-MM-DD
    const sortKey = String(req.query.sort ?? "created_at_desc").trim();
    const orderBy = SORT_MAP[sortKey] || SORT_MAP.created_at_desc;

    /* --------------------------- WHERE build ------------------------- */
    const where = [];
    const params = [];

    if (username) {
      where.push(`al.username LIKE ?`);
      params.push(`%${username}%`);
    }
    if (entity_type) {
      where.push(`al.entity_type LIKE ?`);
      params.push(`%${entity_type}%`);
    }
    if (action) {
      where.push(`al.action = ?`);
      params.push(action);
    }
    if (from) {
      where.push(`al.created_at >= ?`);
      params.push(`${from} 00:00:00`);
    }
    if (to) {
      where.push(`al.created_at <= ?`);
      params.push(`${to} 23:59:59`);
    }
    if (q) {
      // Search username, entity_type, entity_id and JSON keys inside entity_ctx
      where.push(`
        (
          al.username LIKE ?
          OR al.entity_type LIKE ?
          OR al.entity_id LIKE ?
          OR JSON_UNQUOTE(JSON_EXTRACT(al.entity_ctx, '$.ParcelId')) LIKE ?
          OR JSON_UNQUOTE(JSON_EXTRACT(al.entity_ctx, '$.LotNumber')) LIKE ?
          OR JSON_UNQUOTE(JSON_EXTRACT(al.entity_ctx, '$.BarangayNa')) LIKE ?
          OR JSON_SEARCH(al.entity_ctx, 'one', ?) IS NOT NULL
        )
      `);
      const like = `%${q}%`;
      params.push(like, like, like, like, like, like, like);
    }

    const whereSql = where.length ? `WHERE ${where.join(" AND ")}` : "";

    /* ----------------------------- COUNT ----------------------------- */
    const countSql = `SELECT COUNT(*) AS cnt FROM audit_logs al ${whereSql}`;
    const [countRows] = await database.execute(countSql, params);
    const total = countRows?.[0]?.cnt ?? 0;

    /* --------------------------- MAIN DATA --------------------------- */
    const dataSql = `
      SELECT
        al.id,
        al.user_id,
        al.username,
        al.action,
        al.entity_type,
        al.entity_id,
        al.entity_ctx,
        al.changed_fields,
        al.before_data,
        al.after_data,
        al.ip,
        al.user_agent,
        al.created_at
      FROM audit_logs al
      ${whereSql}
      ORDER BY ${orderBy}
      LIMIT ? OFFSET ?
    `;
    const dataParams = [...params, limit, offset];
    const [rows] = await database.execute(dataSql, dataParams);

    /* ---------------------------- SUMMARY ---------------------------- */
    // KPI by action for the current filtered set
    const summarySql = `
      SELECT al.action, COUNT(*) AS count
      FROM audit_logs al
      ${whereSql}
      GROUP BY al.action
    `;
    const [summaryRows] = await database.execute(summarySql, params);

    // Normalize summary into { CREATE: n, UPDATE: n, DELETE: n, ... }
    const actionSummary = Object.create(null);
    for (const r of summaryRows) {
      actionSummary[r.action] = Number(r.count) || 0;
    }

    // Set helpful header for DataTables/React tables
    res.set("X-Total-Count", String(total));

    return res.json({
      data: rows,
      total,
      page,
      limit,
      pages: Math.max(Math.ceil(total / limit), 1),
      summary: actionSummary,
    });
  } catch (err) {
    console.error("getAuditLogs error:", err);
    return res.status(500).json({ error: err.message });
  }
}
