CREATE TABLE building ( 
	building_num BIGINT PRIMARY KEY AUTO_INCREMENT, 
	buildingName VARCHAR(255), 
	buildingUseType VARCHAR(255), 
	buildingType VARCHAR(255), 
	area VARCHAR(255)) 
AUTO_INCREMENT = 1000;
commit;