// src/routes/userRoute.js
import express from "express";
import dotenv from "dotenv";
import jwt from "jsonwebtoken";

import {
  // auth
  signup,
  login,
  // admin users CRUD
  createUser,
  listFilteredUsers,
  getUserById,
  updateUser,
  deleteUser,
  // (optional) add these in controller if/when you implement:
  // updateUserPassword,
  // bulkUpdateUsers,
} from "../controllers/userController.js";

dotenv.config();

const router = express.Router();

/* ------------------------------------------------------------------ */
/* Inline middlewares (self-contained para hindi mag-break ang import) */
/* ------------------------------------------------------------------ */

/**
 * Bearer JWT auth
 * Expect header: Authorization: Bearer <token>
 * Payload (from login): { id, username, role, iat, exp }
 */
function auth(req, res, next) {
  try {
    const hdr = req.headers.authorization || "";
    const [scheme, token] = hdr.split(" ");
    if (scheme !== "Bearer" || !token) {
      return res
        .status(401)
        .json({ result: 0, error: "Missing or invalid Authorization header" });
    }
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    return next();
  } catch (err) {
    return res.status(401).json({ result: 0, error: "Invalid or expired token" });
  }
}

/**
 * Admin gate
 * Only ADMIN can access admin routes.
 * (Legacy: also accept 'admin' | 'superadmin' | 1 while transitioning)
 */
function isAdmin(req, res, next) {
  const raw = req.user?.role;
  const role = String(raw ?? "").toUpperCase();

  const isModernAdmin = role === "ADMIN";
  const isLegacyAdmin =
    role === "ADMIN" ||               // redundant, but explicit
    role === "SUPERADMIN" ||
    String(raw).toLowerCase() === "admin" ||
    String(raw).toLowerCase() === "superadmin" ||
    Number(raw) === 1;

  if (isModernAdmin || isLegacyAdmin) return next();
  return res.status(403).json({ result: 0, error: "Admin access required" });
}

/* ------------------------------- Routes ------------------------------ */

/** Public auth */
router.post("/signup", signup);
router.post("/login", login);

/** Admin: Users CRUD
 * Final paths (server mounts at /api):
 *  POST   /api/admin/users         → createUser
 *  GET    /api/admin/users         → listFilteredUsers
 *  GET    /api/admin/users/:id     → getUserById
 *  PATCH  /api/admin/users/:id     → updateUser
 *  DELETE /api/admin/users/:id     → deleteUser
 */
router.post("/admin/users", auth, isAdmin, createUser);
router.get("/admin/users", auth, isAdmin, listFilteredUsers);
router.get("/admin/users/:id", auth, isAdmin, getUserById);
router.patch("/admin/users/:id", auth, isAdmin, updateUser);
router.delete("/admin/users/:id", auth, isAdmin, deleteUser);

/** (Optional) dedicated password change route
 *  Implement updateUserPassword in your controller before enabling this.
 */
// router.patch("/admin/users/:id/password", auth, isAdmin, updateUserPassword);

/** (Optional) bulk actions (activate/disable/assign role, etc.)
 *  Implement bulkUpdateUsers(req,res) in your controller before enabling this.
 */
// router.patch("/admin/users:bulk", auth, isAdmin, bulkUpdateUsers);

export default router;
