// src/middleware/auth.js
import jwt from "jsonwebtoken";

/**
 * JWT Auth middleware
 *
 * Looks for token in:
 *   1) Authorization header: "Bearer <token>"
 *   2) req.cookies.token  (optional; if you're using cookie-parser)
 *
 * On success: attaches { id, username, role } to req.user
 * On failure: 401 with a clear message
 */
export default function auth(req, res, next) {
  try {
    let token = null;

    // 1) Bearer token from Authorization header
    const authHeader = req.headers.authorization || "";
    const [scheme, raw] = authHeader.split(" ");
    if (scheme === "Bearer" && raw) token = raw;

    // 2) Fallback to cookie (if cookie-parser is enabled)
    if (!token && req.cookies && req.cookies.token) {
      token = req.cookies.token;
    }

    if (!token) {
      return res
        .status(401)
        .json({ result: 0, error: "Missing token. Please login." });
    }

    // Verify token
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    // Attach to request for downstream handlers/middlewares
    req.user = {
      id: decoded.id,
      username: decoded.username,
      role: decoded.role,
    };

    return next();
  } catch (err) {
    const msg =
      err?.name === "TokenExpiredError"
        ? "Token expired. Please login again."
        : "Invalid token.";
    return res.status(401).json({ result: 0, error: msg });
  }
}
