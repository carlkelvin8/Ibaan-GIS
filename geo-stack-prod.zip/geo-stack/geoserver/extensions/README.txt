Place the MySQL JDBC extension ZIP for your GeoServer version in this folder.
Download from: https://sourceforge.net/projects/geoserver/files/GeoServer/
Example filename: geoserver-2.23.2-mysql-plugin.zip

Rename to: mysql-plugin.zip
Do NOT unzip. The container auto-installs any ZIP in /opt/geoserver/exts.
